#!/usr/bin/env python3
#You can ignore this file in question 1.  It is used in Question 3.
import datetime

print('Success?')
print(datetime.datetime.now())
