# OPS300-Vemicelli
Repo for OPS300NBB Fall 2023 Practical #2 Should not be used for other purposes. It has deliberate errors.
